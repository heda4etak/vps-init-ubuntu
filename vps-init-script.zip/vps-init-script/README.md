# VPS Init Script for Ubuntu 24.04

This script configures a fresh Ubuntu 24.04 VPS with:

- ✅ SSH port change and SSH key authentication
- 🔐 Disables password login for SSH
- 🔥 Enables UFW with SSH, HTTP, and HTTPS open
- ⚙️ Adds network optimizations (sysctl)
- 🚫 Does NOT install XanMod BBR3 kernel automatically – do it manually if needed

## Usage

```bash
bash setup_vps.sh
```
